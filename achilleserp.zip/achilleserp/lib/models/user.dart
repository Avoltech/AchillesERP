class User {
  String uid;
  String name;
  String department;
  String position1;
  String position2;
  String position3;
  int formCounter;
  User({this.uid, this.name, this.department, this.position1, this.position2, this.position3, this.formCounter});
}