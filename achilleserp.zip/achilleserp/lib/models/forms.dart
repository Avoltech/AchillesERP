class firstForm {
  String dateTime;
  String senderUid;
  String senderName;
  List<String> receiverNames;
  List<String> rids;
  String firstField;
  String secondField;
  String img1;
  String img2;
  String img3;
  String img4;
  String img5;
  String img6;

  firstForm({this.dateTime, this.senderUid,
    this.senderName, this.receiverNames,
    this.rids,
    this.firstField, this.secondField,
    this.img1, this.img2, this.img3,
    this.img4, this.img5, this.img6
  });
}