import 'package:flutter/material.dart';
import 'package:achilleserp/models/user.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:achilleserp/screens/forms/detail/detailPageFormA.dart';
import 'package:achilleserp/screens/forms/approval/approvalFormA.dart';

class toApprove extends StatefulWidget {
  final User user;
  toApprove({Key key, this.user}) : super(key: key);

  @override
  _toApproveState createState() => _toApproveState();
}

class _toApproveState extends State<toApprove> {
  Future _data;

  Future getForms(String uid) async {
    QuerySnapshot qs1 = await Firestore.instance.collection('forms').where('receiverUid1', isEqualTo: uid).where('approval1', isEqualTo: 0).getDocuments();
    QuerySnapshot qs2 = await Firestore.instance.collection('forms').where('receiverUid2', isEqualTo: uid).where('approval2', isEqualTo: 0).getDocuments();
    //print(qs.documents[0].data);
    return (qs1.documents + qs2.documents);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print(">>>>>=====INIT=====<<<<<");
    //print(widget.user_.toString());
    print(widget.user.uid);
    _data = getForms(widget.user.uid);
    _data.whenComplete(() => print(_data));
    print('Completed init');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.blue[50],
        appBar: AppBar(
          iconTheme: new IconThemeData(color: Colors.indigo[800]),
          elevation: 6,
          backgroundColor: Colors.white,
          title: Text(
            "Head Approval",
            style: TextStyle(
              color: Colors.indigo[800],
              fontWeight: FontWeight.w800,
              letterSpacing: 2.0,
            ),
          ),
          centerTitle: true,
        ),
        body: Container(
            child: FutureBuilder(
                future: _data,
                builder: (_, snapshot)
                {
                  if(snapshot.connectionState == ConnectionState.waiting) {
                    return Center(
                      child: Text("Loading...."),
                    );
                  }else {
                    print(snapshot.data.toString());
                    if(snapshot.data.length == 0) {
                      return Center(child: Text('No forms to show'),);
                    }
                    else {
                      return ListView.builder(
                        //separatorBuilder: (_, __) => Divider(),
                        itemCount: snapshot.data.length,
                        itemBuilder: (_, index) {
                          return Container(
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [BoxShadow(
                                    color: Colors.grey.withOpacity(0.5),
                                    blurRadius: 5,
                                    spreadRadius: 1,
                                    offset: Offset(0, 2)
                                )]
                            ),
                            margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
                            child: ListTile(
                              title: Text(snapshot.data[index].data['dateTime']),
                              subtitle: Text(snapshot.data[index].data['receiverName1'] + '\n' +
                                snapshot.data[index].data['receiverName2']
                                ),
                              onTap: () {
                                if (snapshot.data[index].data['formType'] == 'A') {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (context) => ApprovalFormA(post: snapshot.data[index], user: widget.user))
                                  );
                                }
                              },
                            ),
                          );
                        },
                      );
                    }

                  }
                }
            )
        )
    );
  }
}
