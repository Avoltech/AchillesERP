import 'package:flutter/material.dart';
import 'package:achilleserp/services/auth.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:achilleserp/models/user.dart';
import 'package:achilleserp/services/database.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:achilleserp/screens/loading.dart';
import 'package:achilleserp/screens/forms/forms_history.dart';
import 'package:achilleserp/screens/forms/create/createForm.dart';
import 'package:achilleserp/screens/heads/toApprove.dart';
import 'package:achilleserp/screens/forms/returned_forms.dart';
import 'package:achilleserp/screens/procurement/procurementApproval.dart';
import 'package:achilleserp/screens/procurement/memberProcurementApproval.dart';
import 'package:achilleserp/screens/fullyApproved/fullyApprovedList.dart';
import 'package:achilleserp/screens/approvedUserHistory.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

@override
Widget build(BuildContext context) {
String _showAlert = null;
_showAlert = ModalRoute.of(context).settings.arguments;



final user = Provider.of<FirebaseUser>(context);
Future <Map<String, dynamic>> document = DatabaseService().getUserDetails(user.uid);


bool loading = false;

_showSnackBarNoForms() {
  final snackBar = new SnackBar(
    content: Text('No forms to show!', style: TextStyle(color: Colors.indigo[800], fontWeight: FontWeight.w400, fontStyle: FontStyle.italic), ),
    duration: Duration(seconds: 2),
    backgroundColor: Colors.white,
  );
  _scaffoldKey.currentState.showSnackBar(snackBar);
}



showAlertDialog(BuildContext context, String di) {

  List <String> dialogs = ['Form Submitted Successfully', 'Form has been approved by you.', 'Form has been disapproved by you.'];
  String dialog;

  if(di == 'uploaded' ) {dialog = dialogs[0];}
  if(di == 'approved' ) {dialog = dialogs[1];}
  if(di == 'disapproved' ) {dialog = dialogs[2];}

  // set up the button
  Widget okButton = FlatButton(
    child: Text("Okay"),
    onPressed: () {
      Navigator.of(context).pop();
    },
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("Success"),
    content: Text(dialog),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}



return _showAlert != null ? showAlertDialog(context, _showAlert) : Scaffold(
    key: _scaffoldKey,
    appBar: AppBar(
      iconTheme: new IconThemeData(color: Colors.indigo[800]),
      elevation: 6,
      backgroundColor: Colors.white,
      title: Text(
        "E.S.T.A",
        style: TextStyle(
          color: Colors.indigo[800],
          fontWeight: FontWeight.w800,
          letterSpacing: 2.0,
        ),
      ),
      centerTitle: true,
      actions: <Widget>[
        FlatButton.icon(
          icon: Icon(
            Icons.person_outline,
            color: Colors.indigo[800],
          ),
          label: Text(
            'Sign Out',
            style: TextStyle(
              color: Colors.indigo[800],
            ),
          ),
          onPressed: () {
            //_auth.signOut();
            Navigator.pushReplacementNamed(context, '/sign_in');
          },
        )
      ],
    ),
    endDrawer: Drawer(
        child: Container(
          color: Colors.purple[500],
        )
    ),
    drawer: Drawer(
      child: Container(
        color: Colors.greenAccent,
        child: Text("drawer here"),
      ),

    ),
    body: StreamBuilder(
      stream: Firestore.instance.collection('users').where("uid", isEqualTo: user.uid).snapshots(),
      builder: (context, snapshot) {
        if(snapshot.connectionState == ConnectionState.waiting) {
          return Center(
            child: Text("Loading...."),
          );
        }
        else {
          User user = User(
            uid: snapshot.data.documents[0]['uid'].toString(),
            name: snapshot.data.documents[0]['name'].toString(),
            department: snapshot.data.documents[0]['department'].toString(),
            position1: snapshot.data.documents[0]['position1'].toString(),
            position2: snapshot.data.documents[0]['position2'].toString(),
            position3: snapshot.data.documents[0]['position3'].toString(),
            formCounter: snapshot.data.documents[0]['formCounter'],
          );

          return Container(
              padding: EdgeInsets.all(10),
              color: Colors.blue[50],
              child: GridView.count(
                crossAxisCount: 2,
                children: <Widget>[
                  GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => createForm(user: user))
                        );
                      },
                      child: menuTile(
                          icon_name: Icons.add_circle, tile_name: 'Create')
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => returnedForms(user: user))
                      );
                    },
                    child: menuTile(icon_name: Icons.assignment_return,
                        tile_name: 'Returned'),
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>
                              approvedUserHistory(user_: user))
                      );
                    },
                    child: menuTile(icon_name: Icons.assignment_turned_in,
                        tile_name: 'Approved'),
                  ),
                  GestureDetector(
                    onTap: () {
                      snapshot.data.documents[0]['formCounter'] == 0 ?
                      _showSnackBarNoForms()
                          :
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => formHistory(user_: user))
                      );
                    },
                    child: menuTile(
                        icon_name: Icons.watch_later, tile_name: 'History'),
                  ),
                  user.position2 == 'head' && user.department != 'procurement' ?
                  GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => toApprove(user: user))
                        );
                      },
                      child: menuTile(icon_name: Icons.local_post_office,
                          tile_name: 'To Approve')) :
                  user.department == 'procurement' ?
                  GestureDetector(
                      onTap: () {
                        if (user.position2 == 'head') {
                          Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) =>
                                  ProcurementToApprove(user: user))
                          );
                        } else {
                          Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) =>
                                  MemberProcurementToApprove(user: user))
                          );
                        }
                      },
                      child: menuTile(icon_name: Icons.monetization_on,
                          tile_name: 'Procurement\nApproval')) :
                  Container(),
                  user.department == 'procurement' ?
                  GestureDetector(
                    onTap: () {
                      print('Pressed');
                      Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>
                              fullyApprovedList(user: user))
                      );
                    },
                    child: menuTile(icon_name: Icons.picture_as_pdf,
                        tile_name: 'Fully Approved'),
                  ) :
                  Container()
                ],
              )
          );
        }
      }
    )
    );
  }
}



//
//class showDialog extends StatelessWidget {
//  String di;
//  showDialog({Key key, this.di}) : super(key: key);
//
//
//  @override
//  Widget build(BuildContext context) {
//    List <String> dialogs = ['Form Submitted Successfully', 'Form has been approved by you.', 'Form has been disapproved by you.'];
//    String dialog;
//
//    if(di == 'uploaded' ) {dialog = dialogs[0];}
//    if(di == 'approved' ) {dialog = dialogs[1];}
//    if(di == 'disapproved' ) {dialog = dialogs[2];}
//
//    return AlertDialog(
//      shape: RoundedRectangleBorder(
//        borderRadius: BorderRadius.circular(15),
//      ),
//      content: Text(
//        dialog,
//        style: TextStyle(
//          fontSize: 20,
//          fontWeight: FontWeight.w600,
//        ),
//      ),
//      actions: <Widget>[
//        FlatButton(
//          child: Align(
//            alignment: Alignment.center,
//            child: Text('Okay'),
//          ),
//          onPressed: () {
//            Navigator.of(context).pop();
//          },
//        )
//      ],
//    );
//  }
//}



class menuTile extends StatelessWidget {

  final IconData icon_name;
  final String tile_name;

  menuTile({this.icon_name, this.tile_name});

  @override
  Widget build(BuildContext context) {
    return Container(
          margin: EdgeInsets.all(15),
         // height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: Colors.white.withOpacity(0.9),
              boxShadow: [
                BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    blurRadius: 5,
                    spreadRadius: 1,
                    offset: Offset(0, 4)
                )
              ]
          ),

            child: Column(
              children: <Widget>[
                SizedBox(height: 20,),
                Icon(
                  icon_name,
                  size: 90,
                  color: Colors.blue[200],
                ),
                SizedBox(height: 5,),
                 Text(
                  tile_name,
                  style: TextStyle(
                      color: Colors.indigo[800],
                      fontSize: 18,
                  ),
                ),
              ],
            ),

    );
  }
}
