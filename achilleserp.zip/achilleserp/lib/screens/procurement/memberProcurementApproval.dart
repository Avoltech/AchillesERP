import 'package:flutter/material.dart';
import 'package:achilleserp/models/user.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:achilleserp/screens/forms/detail/detailPageFormA.dart';
import 'package:achilleserp/screens/forms/approval/approvalFormA.dart';
import 'package:achilleserp/screens/procurement/procurementFormA.dart';

class MemberProcurementToApprove extends StatefulWidget {
  final User user;
  MemberProcurementToApprove({Key key, this.user}) : super(key: key);

  @override
  _MemberProcurementToApproveState createState() => _MemberProcurementToApproveState();
}

class _MemberProcurementToApproveState extends State<MemberProcurementToApprove> {
  Future _data;

  Future getForms() async {


    //FORM     A
    QuerySnapshot qs1 = await Firestore.instance.collection('forms').where('formType', isEqualTo: 'A').where('status', isEqualTo: 'stage1').where('procurementReceiver', isEqualTo: widget.user.uid).getDocuments();


    //FORM     B


    //FORM     C


    //FORM     D

    //print(qs.documents[0].data);
    return (qs1.documents);
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print(">>>>>=====INIT=====<<<<<");
    //print(widget.user_.toString());
    print(widget.user.uid);
    _data = getForms();
    _data.whenComplete(() => print(_data));
    print('Completed init');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.blue[50],
        appBar: AppBar(
          iconTheme: new IconThemeData(color: Colors.indigo[800]),
          elevation: 6,
          backgroundColor: Colors.white,
          title: Text(
            "Procurement Member Approval",
            style: TextStyle(
              color: Colors.indigo[800],
              fontWeight: FontWeight.w800,
              letterSpacing: 2.0,
            ),
          ),
          centerTitle: true,
        ),
        body: Container(
            child: FutureBuilder(
                future: _data,
                builder: (_, snapshot)
                {
                  if(snapshot.connectionState == ConnectionState.waiting) {
                    return Center(
                      child: Text("Loading...."),
                    );
                  }else {
                    print(snapshot.data.toString());
                    if(snapshot.data.length == 0) {
                      return Center(child: Text('No forms to show'),);
                    }
                    else {
                      return ListView.builder(
                        //separatorBuilder: (_, __) => Divider(),
                        itemCount: snapshot.data.length,
                        itemBuilder: (_, index) {
                          return Container(
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [BoxShadow(
                                    color: Colors.grey.withOpacity(0.5),
                                    blurRadius: 5,
                                    spreadRadius: 1,
                                    offset: Offset(0, 2)
                                )]
                            ),
                            margin: EdgeInsets.fromLTRB(10, 10, 10, 10),
                            child: ListTile(
                              title: Text(snapshot.data[index].data['dateTime']),
                              subtitle: Text(snapshot.data[index].data['receiverName1'] + '\n' +
                                  snapshot.data[index].data['receiverName2']
                              ),
                              onTap: () {
                                if (snapshot.data[index].data['formType'] == 'A') {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (context) => ProcurementApprovalFormA(post: snapshot.data[index], user: widget.user))
                                  );
                                }
                              },
                            ),
                          );
                        },
                      );
                    }

                  }
                }
            )
        )
    );
  }
}
